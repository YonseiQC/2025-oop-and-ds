#include <benchmark/benchmark.h>
#include <list>
#include <vector>

static void BM_ListInsert(benchmark::State& state) {
	for (auto _ : state) {
		std::list<int> l;
		for (int i = 0; i < state.range(0); i++) {
			l.push_front(i);
		}
	}
}
// Register the function as a benchmark
BENCHMARK(BM_ListInsert)->Arg(100)->Arg(1'000)->Arg(10'000)->Arg(100'000);

// Define another benchmark
static void BM_VectorInsert(benchmark::State& state) {
	for (auto _ : state) {
		std::vector<int> v;
		for (int i = 0; i < state.range(0); i++) {
			v.insert(v.begin(), i);
		}
	}
}
BENCHMARK(BM_VectorInsert)->Arg(100)->Arg(1'000)->Arg(10'000)->Arg(100'000);

BENCHMARK_MAIN();
